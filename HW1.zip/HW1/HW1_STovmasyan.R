library(ggplot2)
library(diffusion)

tesla <- read.csv('tesla_superchargers.csv')
tesla
tesla <- tesla[c(1:10),]

tesla[['Quantity']]

# Estimate Bass model parameters for the look-alike innovation
diff <- diffusion(tesla$Quantity)
diff
p <- round(diff$w,4)(1)
q <- round(diff$w,4)(2)
m <- round(diff$w,4)(3)
t <- 10

# Make predictions of the diffusion of the innovation you chose at stage 1
tesla$pred_sales <- bass.f(1:10, p, q )*m
ggplot(data = tesla, aes(x = Year, y = Quantity)) + geom_bar(stat = 'identity') + geom_point(mapping = aes(x = Year, y = pred_sales), color = 'blue')

# Estimate the number of adopters by period. Thus, you will need to estimate the potential market share. You can use Fermi’s logic here as well.

bass.f <- function(t,p,q){
  ((p+q)**2/p)*exp(-(p+q)*t)/
    (1+(q/p)*exp(-(p+q)*t))**2
}

bass.F <- function(t,p,q){ 
  (1-exp(-(p+q)*t))/
    (1+(q/p)*exp(-(p+q)*t))
}

bass.f(t,p,q)
bass.F(t,p,q)

At = m * bass.F(t,p,q) 
at = m * bass.f(t,p,q) 

At  # number of previous adopters at the time t
at  # number of adopters by time t

